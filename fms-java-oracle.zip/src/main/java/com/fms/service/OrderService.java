package com.fms.service;

import com.fms.domain.AppUser;
import com.fms.domain.NotFoundException;
import com.fms.domain.OrderInfo;
import com.fms.domain.OrderLine;
import com.fms.domain.OrderType;
import com.fms.domain.Product;
import com.fms.repo.OrderInfoRepository;
import com.fms.repo.OrderLineRepository;
import com.fms.repo.PaymentRepository;
import com.fms.repo.ProductRepository;
import com.fms.repo.OrderSummary;
import com.fms.repo.Totals;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

/**
 * Creating and changing purchases, sales and offers. Replaces addproduct_Click,
 * Delete_Click and BindGrid in the New* and ListOf*Update pages.
 */
@Service
public class OrderService {

    private final OrderLineRepository lines;
    private final PricingService pricing;
    private final PartyService parties;
    private final OrderInfoRepository infos;
    private final PaymentRepository payments;
    private final ProductRepository products;
    private final ConfigService config;
    private final AuditService audit;
    private final ShelfService shelves;

    public OrderService(OrderLineRepository lines, PricingService pricing, PartyService parties,
                        OrderInfoRepository infos, PaymentRepository payments, ProductRepository products,
                        ConfigService config, AuditService audit, ShelfService shelves) {
        this.shelves = shelves;
        this.lines = lines;
        this.pricing = pricing;
        this.parties = parties;
        this.infos = infos;
        this.payments = payments;
        this.products = products;
        this.config = config;
        this.audit = audit;
    }

    /**
     * A fresh 8-digit order number: 00000001, 00000002, ... The order exists
     * once its first line is saved. Numbers already in use (for example codes
     * imported from the old system) are skipped. The sequence is shared by
     * purchases, sales and offers, so a number is never reused across types.
     */
    @Transactional
    public String newOrderCode() {
        while (true) {
            String code = String.format("%08d", lines.nextOrderCode().longValue());
            if (!lines.existsByOrderCode(code)) {
                return code;
            }
        }
    }

    /** A new order that has no number yet (the number is given when the first product is saved). */
    public OrderView newOrder(OrderType type) {
        return new OrderView(type, null, List.of(), null, null, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO);
    }

    @Transactional(readOnly = true)
    public OrderView load(OrderType type, String code) {
        List<OrderLine> list = lines.findByOrderTypeAndOrderCodeOrderByCreatedAtAscIdAsc(type, code);
        PartyInfo provider = null;
        PartyInfo buyer = null;
        if (!list.isEmpty()) {
            provider = parties.provider(type, list.get(0).getProviderName());
            buyer = parties.buyer(type, list.get(0).getBuyerName());
        }
        BigDecimal noVat = list.stream().map(OrderLine::getValueNoVat).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal vat = list.stream().map(OrderLine::getVatValue).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal withVat = list.stream().map(OrderLine::getValueWithVat).reduce(BigDecimal.ZERO, BigDecimal::add);
        return new OrderView(type, code, list, provider, buyer, noVat, vat, withVat);
    }

    /**
     * Administrators can change any order. Other users can build a new order
     * and change orders they created. (The original blocked regular users from
     * the ListOf*Update pages entirely but let them edit while creating.)
     */
    public boolean canEdit(AppUser user, OrderView order) {
        return user.isAdmin() || order.isEmpty() || user.getUsername().equals(order.createdBy());
    }

    /**
     * Adds a product to an order. Pass {@code code = null} for a new order: it
     * gets the next number only after every check has passed, so abandoned or
     * rejected new orders don't leave gaps in the numbering.
     */
    @Transactional
    public OrderLine addLine(OrderType type, String code, AddLineForm form, AppUser user) {
        OrderView order = code == null ? newOrder(type) : load(type, code);
        if (!canEdit(user, order)) {
            throw new OrderException("You can only change orders you created.");
        }
        if (!StringUtils.hasText(form.getProvider()) || !StringUtils.hasText(form.getBuyer())) {
            throw new OrderException("Choose the " + type.getProviderLabel().toLowerCase()
                    + " and the " + type.getBuyerLabel().toLowerCase() + " first.");
        }
        if (!StringUtils.hasText(form.getProduct())) {
            throw new OrderException("Choose a product.");
        }
        if (form.getQuantity() < 1) {
            throw new OrderException("Quantity must be at least 1.");
        }

        // Once an order has lines, its provider and buyer are fixed (the
        // original disabled both drop-downs on the update pages).
        String providerName = order.isEmpty() ? form.getProvider() : order.lines().get(0).getProviderName();
        String buyerName = order.isEmpty() ? form.getBuyer() : order.lines().get(0).getBuyerName();

        if (order.isEmpty() && !parties.isValidProvider(type, providerName)) {
            throw new OrderException("Unknown " + type.getProviderLabel().toLowerCase() + ": " + providerName);
        }
        boolean buyerIsClient = parties.isValidBuyer(type, buyerName);
        if (order.isEmpty() && !buyerIsClient && type != OrderType.OFFER) {
            throw new OrderException("Unknown " + type.getBuyerLabel().toLowerCase() + ": " + buyerName);
        }

        Quote q = pricing.quote(type, form.getProduct(), buyerName, form.getManualDiscount(), form.getQuantity(),
                type == OrderType.PURCHASE ? form.getUnitPrice() : null);
        if (type.isOutgoing() && q.exceedsStock()) {
            long inStock = Math.max(0, q.available());
            throw new OrderException(inStock == 0
                    ? q.productName() + " is out of stock. Record a purchase first."
                    : "Not enough stock: you entered " + q.requestedQuantity() + " " + q.unit()
                      + " of " + q.productName() + ", but only " + inStock + " " + q.unit()
                      + " are in stock. Lower the quantity.");
        }

        // Shelves: a sale takes from the chosen shelf (or from stock that isn't on a shelf).
        Product product = products.findByName(q.productName()).orElseThrow(() -> new OrderException("Choose a product."));
        com.fms.domain.Shelf shelf = null;
        if (type == OrderType.SALE) {
            shelf = shelves.take(product, form.getShelfId(), q.quantity());
        }

        if (code == null) {
            code = newOrderCode();
        }

        OrderLine line = new OrderLine();
        line.setOrderType(type);
        line.setOrderCode(code);
        line.setCreatedAt(LocalDateTime.now());
        line.setProductName(q.productName());
        line.setProviderName(providerName);
        line.setBuyerName(buyerName);
        line.setUnit(q.unit());
        line.setQuantity(q.quantity());
        line.setUnitPrice(q.unitPrice());
        line.setDiscountPercent(q.discountPercent());
        line.setValueNoVat(q.valueNoVat());
        line.setVatValue(q.vatValue());
        line.setValueWithVat(q.valueWithVat());
        line.setCreatedBy(user.getUsername());
        if (type == OrderType.SALE) {
            // Cost of the goods sold, at today's average purchase cost (for real profit figures).
            products.findByName(q.productName()).ifPresent(p -> line.setUnitCost(pricing.averageCost(p)));
        }
        if (type == OrderType.OFFER) {
            line.setExistingClient(buyerIsClient ? "Y" : "N");
            if (!buyerIsClient && order.isEmpty()) {
                parties.saveProspect(buyerName, form.getProspectTin(), form.getProspectAddress(),
                        form.getProspectEmail(), form.getProspectPhone());
            }
        }
        if (type == OrderType.PURCHASE && form.getShelfId() != null) {
            shelf = shelves.put(product, form.getShelfId(), q.quantity());
        }
        if (shelf != null) {
            line.setShelfId(shelf.getId());
            line.setShelfCode(shelf.getCode());
        }
        OrderLine saved = lines.save(line);
        if (order.isEmpty()) {
            createInfo(type, code);
        } else {
            lines.touchOrder(type, code, LocalDateTime.now());
        }
        audit.log("ADD_LINE", type.getLabel(), code, q.quantity() + " " + q.unit() + " " + q.productName()
                + " at " + Money.format(q.unitPrice()) + " (" + buyerName + ")"
                + (shelf == null ? "" : ", shelf " + shelf.getCode()));
        return saved;
    }

    @Transactional
    public void deleteLine(OrderType type, String code, Long lineId, AppUser user) {
        OrderView order = load(type, code);
        if (!canEdit(user, order)) {
            throw new OrderException("You can only change orders you created.");
        }
        OrderLine line = lines.findByIdAndOrderType(lineId, type)
                .filter(l -> l.getOrderCode().equals(code))
                .orElseThrow(() -> new NotFoundException("Line not found"));
        undoShelf(line);
        lines.delete(line);
        lines.touchOrder(type, code, LocalDateTime.now());
        audit.log("REMOVE_LINE", type.getLabel(), code, line.getQuantity() + " " + line.getUnit() + " " + line.getProductName());
    }

    /** Deleting a whole order is for administrators only, as in the original lists. */
    @Transactional
    public void deleteOrder(OrderType type, String code, AppUser user) {
        if (!user.isAdmin()) {
            throw new OrderException("Only administrators can delete orders.");
        }
        OrderView order = load(type, code);
        order.lines().forEach(this::undoShelf);
        lines.deleteOrder(type, code);
        payments.deleteOrder(type, code);
        infos.deleteOrder(type, code);
        audit.log("DELETE_ORDER", type.getLabel(), code, order.isEmpty() ? null
                : order.lines().size() + " lines, " + Money.format(order.valueWithVat()) + " with VAT, "
                  + order.lines().get(0).getBuyerName());
    }

    /** Removing a sale line puts it back on its shelf; removing a purchase line takes it off. */
    private void undoShelf(OrderLine l) {
        if (l.getShelfId() == null) {
            return;
        }
        products.findByName(l.getProductName()).ifPresent(p -> {
            if (l.getOrderType() == OrderType.SALE) {
                shelves.put(p, l.getShelfId(), l.getQuantity());
            } else if (l.getOrderType() == OrderType.PURCHASE) {
                shelves.takeUpTo(p, l.getShelfId(), l.getQuantity());
            }
        });
    }

    // ------------------------------------------------------------ order info

    /** Creates the order's info row: payment due date, or offer validity. */
    private OrderInfo createInfo(OrderType type, String code) {
        OrderInfo info = new OrderInfo();
        info.setOrderType(type);
        info.setOrderCode(code);
        var c = config.get();
        if (type == OrderType.OFFER) {
            info.setOfferStatus(OrderInfo.OfferStatus.OPEN);
            info.setValidUntil(LocalDate.now().plusDays(c.getOfferValidDays()));
        } else {
            info.setDueDate(LocalDate.now().plusDays(c.getPaymentTermsDays()));
        }
        return infos.save(info);
    }

    /**
     * The order's info. Orders saved before this feature (or imported) get
     * defaults based on their date, without writing anything.
     */
    @Transactional(readOnly = true)
    public OrderInfo info(OrderType type, String code, LocalDate orderDate) {
        return infos.findByOrderTypeAndOrderCode(type, code).orElseGet(() -> {
            OrderInfo i = new OrderInfo();
            i.setOrderType(type);
            i.setOrderCode(code);
            var c = config.get();
            LocalDate d = orderDate == null ? LocalDate.now() : orderDate;
            if (type == OrderType.OFFER) {
                i.setOfferStatus(OrderInfo.OfferStatus.OPEN);
                i.setValidUntil(d.plusDays(c.getOfferValidDays()));
            } else {
                i.setDueDate(d.plusDays(c.getPaymentTermsDays()));
            }
            return i;
        });
    }

    private OrderInfo infoForUpdate(OrderType type, String code) {
        OrderView order = load(type, code);
        if (order.isEmpty()) {
            throw new NotFoundException("Order not found");
        }
        return infos.findByOrderTypeAndOrderCode(type, code).orElseGet(() -> {
            OrderInfo i = info(type, code, order.lines().get(0).getCreatedAt().toLocalDate());
            return infos.save(i);
        });
    }

    @Transactional
    public void updateDueDate(OrderType type, String code, LocalDate dueDate, AppUser user) {
        if (!canEdit(user, load(type, code))) {
            throw new OrderException("You can only change orders you created.");
        }
        OrderInfo i = infoForUpdate(type, code);
        i.setDueDate(dueDate);
        infos.save(i);
        audit.log("SET_DUE_DATE", type.getLabel(), code, String.valueOf(dueDate));
    }

    @Transactional
    public void updateOffer(String code, OrderInfo.OfferStatus status, LocalDate validUntil, AppUser user) {
        if (!canEdit(user, load(OrderType.OFFER, code))) {
            throw new OrderException("You can only change offers you created.");
        }
        OrderInfo i = infoForUpdate(OrderType.OFFER, code);
        if (i.getConvertedTo() != null) {
            throw new OrderException("This offer was already turned into sale " + i.getConvertedTo() + ".");
        }
        i.setOfferStatus(status);
        i.setValidUntil(validUntil);
        infos.save(i);
        audit.log("SET_OFFER_STATUS", "Offer", code, status + ", valid until " + validUntil);
    }

    // ------------------------------------------------------- offer to sale

    /**
     * Turns an offer into a new sale with the same lines and the prices that
     * were offered. Every product must be in stock in full; otherwise nothing
     * is created. An offer to a non-client registers them as a client first
     * (administrators only). Returns the new sale number.
     */
    @Transactional
    public String convertOfferToSale(String offerCode, AppUser user) {
        OrderView offer = load(OrderType.OFFER, offerCode);
        if (offer.isEmpty()) {
            throw new NotFoundException("Offer not found");
        }
        if (!canEdit(user, offer)) {
            throw new OrderException("You can only convert offers you created.");
        }
        OrderInfo info = infoForUpdate(OrderType.OFFER, offerCode);
        if (info.getConvertedTo() != null) {
            throw new OrderException("This offer was already turned into sale " + info.getConvertedTo() + ".");
        }
        String buyer = offer.lines().get(0).getBuyerName();
        if (!parties.isClient(buyer)) {
            if (!user.isAdmin()) {
                throw new OrderException(buyer + " isn't a registered client yet. Ask an administrator to convert this offer;"
                        + " it registers them as a client automatically.");
            }
            parties.registerClientFromProspect(buyer);
        }

        // Check stock for every product before creating anything.
        Map<String, Integer> needed = new LinkedHashMap<>();
        for (OrderLine l : offer.lines()) {
            needed.merge(l.getProductName(), l.getQuantity(), Integer::sum);
        }
        List<String> shortages = new ArrayList<>();
        needed.forEach((product, qty) -> {
            long available = pricing.available(product);
            if (qty > available) {
                shortages.add(product + " (needs " + qty + ", in stock " + Math.max(0, available) + ")");
            }
        });
        if (!shortages.isEmpty()) {
            throw new OrderException("Not enough stock to turn this offer into a sale: " + String.join(", ", shortages) + ".");
        }

        String saleCode = newOrderCode();
        LocalDateTime now = LocalDateTime.now();
        for (OrderLine o : offer.lines()) {
            OrderLine l = new OrderLine();
            l.setOrderType(OrderType.SALE);
            l.setOrderCode(saleCode);
            l.setCreatedAt(now);
            l.setProductName(o.getProductName());
            l.setProviderName(o.getProviderName());
            l.setBuyerName(o.getBuyerName());
            l.setUnit(o.getUnit());
            l.setQuantity(o.getQuantity());
            l.setUnitPrice(o.getUnitPrice());
            l.setDiscountPercent(o.getDiscountPercent());
            l.setValueNoVat(o.getValueNoVat());
            l.setVatValue(o.getVatValue());
            l.setValueWithVat(o.getValueWithVat());
            l.setCreatedBy(user.getUsername());
            Product p = products.findByName(o.getProductName()).orElse(null);
            if (p != null) {
                l.setUnitCost(pricing.averageCost(p));
                com.fms.domain.Shelf sh = shelves.takeAutomatically(p, o.getQuantity());
                if (sh != null) {
                    l.setShelfId(sh.getId());
                    l.setShelfCode(sh.getCode());
                }
            }
            lines.save(l);
        }
        createInfo(OrderType.SALE, saleCode);

        info.setOfferStatus(OrderInfo.OfferStatus.ACCEPTED);
        info.setConvertedTo(saleCode);
        infos.save(info);
        audit.log("CONVERT_OFFER", "Offer", offerCode, "Became sale " + saleCode + " for " + buyer
                + ", " + Money.format(offer.valueWithVat()) + " with VAT");
        return saleCode;
    }

    /**
     * Orders for the list pages. Regular users only see their own, as in the
     * original's "Where Usern = Session['User']".
     */
    @Transactional(readOnly = true)
    public Page<OrderSummary> list(OrderType type, AppUser user, String search,
                                   LocalDate from, LocalDate to, Pageable pageable) {
        return lines.findSummaries(type, scope(user), start(from), end(to), like(search), pageable);
    }

    /** Footer totals for the list: every order matching the same filters, across all pages. */
    @Transactional(readOnly = true)
    public Totals listTotals(OrderType type, AppUser user, String search, LocalDate from, LocalDate to) {
        Totals t = lines.summaryTotals(type, scope(user), start(from), end(to), like(search));
        return t == null ? Totals.empty() : t.orZero();
    }

    private static String scope(AppUser user) {
        return user.isAdmin() ? null : user.getUsername();
    }

    private static String like(String search) {
        return (StringUtils.hasText(search) ? search.trim().toLowerCase() : "") + "%";
    }

    private static LocalDateTime start(LocalDate from) {
        return from == null ? LocalDateTime.of(1900, 1, 1, 0, 0) : from.atStartOfDay();
    }

    private static LocalDateTime end(LocalDate to) {
        return to == null ? LocalDateTime.of(9999, 1, 1, 0, 0) : to.plusDays(1).atStartOfDay();
    }
}
